


//获取游戏开始按键
let gameStartBtn = document.getElementsByClassName('gameStart')[0];

//获取进入时的初始化场景
let initGame = document.getElementsByClassName('initGame')[0];

gameStartBtn.onclick = gameStart;

/**
 * 游戏开始入口
 */
function gameStart () {
    this.style.display = 'none';
    initGame.style.display = 'none';

   new UserPlane();
}

function UserPlane (x,y) {
    this.blood = 100;
    this.speedX = 10;
    this.speedY = 10;
    this.x = x || 0;
    this.y = y || 0;
    this.wrapper = document.querySelector('.box');
    this.dom = document.createElement('div');
    this.timer = null;
    this.createPlane();
    this.move();
}

UserPlane.prototype.createPlane = function () {
    this.dom.setAttribute('class','userPlane');
    this.dom.style.left = this.x;
    this.dom.style.top = this.y;
    this.wrapper.appendChild(this.dom);
}

UserPlane.prototype.move = function () {

   console.log(this.wrapper)
   
    this.wrapper.onmouseenter = function () {
        console.log('ok');
    }
 
}